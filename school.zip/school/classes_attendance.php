<?php
include 'session.php';
include 'database.php';

// Initialize variables
$access_granted = false;
$attendance_records = [];

// Function to sanitize user input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selected_class = $_POST['class'];

    // Get the appropriate table name based on the selected class
    $attendance_table_name = 'attendance' . $selected_class;

    // Initialize search parameters
    $search_student = isset($_POST['search_student']) ? sanitize_input($_POST['search_student']) : '';
    $search_subject = isset($_POST['search_subject']) ? sanitize_input($_POST['search_subject']) : '';
    

    // Construct the SQL query with search parameters
    $sql_attendance = "SELECT students.firstname, students.middlename, students.lastname, subjects.subject_name, $attendance_table_name.attendance_status, $attendance_table_name.uploaded_date FROM $attendance_table_name INNER JOIN students ON $attendance_table_name.studentID = students.studentID INNER JOIN subjects ON $attendance_table_name.subject_id = subjects.subject_id WHERE subjects.class = ?";

    // Add selected class as a parameter
    $params = array($selected_class);

    // Add search conditions if any
    if (!empty($search_student)) {
        $sql_attendance .= " AND CONCAT(students.firstname, ' ', students.middlename, ' ', students.lastname) LIKE ?";
        $params[] = "%$search_student%";
    }
    if (!empty($search_subject)) {
        $sql_attendance .= " AND subjects.subject_name LIKE ?";
        $params[] = "%$search_subject%";
    }

    // Prepare and execute the SQL query
    $stmt_attendance = $conn->prepare($sql_attendance);
    $stmt_attendance->bind_param(str_repeat("s", count($params)), ...$params); // Bind all parameters
    $stmt_attendance->execute();
    $result_attendance = $stmt_attendance->get_result();

    // Fetch attendance records into an array
    while ($row = $result_attendance->fetch_assoc()) {
        $attendance_records[] = $row;
    }
    $stmt_attendance->close();

    // Set access granted flag to true
    $access_granted = true;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance Records</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        /* Attendance Container Styles */
        .attendance-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
        }
        .attendance-container h2 {
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 20px;
        }
        .attendance-container table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        .attendance-container th,
        .attendance-container td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .attendance-container th {
            background-color: #f2f2f2;
        }
        /* Search Form Styles */
        .search-form {
            margin-bottom: 20px;
            margin-left: 35%;
        }
        .search-form2 {
            margin-bottom: 20px;
            margin-left: 15%;
        }
        .search-form2 label {
            font-weight: bold;
        }
        .search-form label {
            font-weight: bold;
        }
        .search-form input[type="text"],
        .search-form select {
            padding: 8px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }
        .search-form button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .search-form2 input[type="text"] {
            padding: 8px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }
        .search-form2 button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="attendance-container">
    <h2>View Attendance Records</h2>

    <!-- Form for selecting class -->
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="search-form">
        <select id="class" name="class" required>
            <option value="" disabled selected>Select Class</option>
            <?php for ($i = 1; $i <= 7; $i++) : ?>
                <option value="<?php echo $i; ?>"><?php echo "Class $i"; ?></option>
            <?php endfor; ?>
        </select>
        <button type="submit" name="select_class">Submit</button>
    </form>


    <!-- Display attendance records -->
    <?php if ($access_granted && !empty($attendance_records)) : ?>


    <h3 style ="text-align : center;" >Attendance Records for Class <?php echo $selected_class; ?></h3>

        <table>
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Subject</th>
                    <th>Attendance Status</th>
                    <th>Attendance Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendance_records as $record) : ?>
                    <tr>
                        <td><?php echo $record['firstname'] . ' ' . $record['middlename'] . ' ' . $record['lastname']; ?></td>
                        <td><?php echo $record['subject_name']; ?></td>
                        <td><?php echo $record['attendance_status']; ?></td>
                        <td><?php echo $record['uploaded_date']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif ($access_granted && empty($attendance_records)) : ?>
        <p>No attendance records found for Class <?php echo $selected_class; ?></p>
    <?php endif; ?>
</div>

</body>
</html>
