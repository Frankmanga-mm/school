<?php
include 'session.php';
// Include the database connection file
include 'database.php';

// Initialize error variable
$error = "";
$success_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $subjectName = $_POST['subjectName'];
    $class = $_POST['class'];
    $teacherName = $_POST['teacher']; // Store the selected teacher's name

    // Retrieve teacherID and email based on the selected teacher's full name
    $retrieveTeacherInfoSQL = "SELECT teacherID, email FROM teachers WHERE CONCAT(firstname, ' ', lastname) = '$teacherName'";
    $result = $conn->query($retrieveTeacherInfoSQL);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $teacherID = $row['teacherID'];
        $teacherEmail = $row['email']; // Get teacher's email

        // Proceed to register subject with the retrieved teacherID and email
        $sql = "INSERT INTO subjects (subject_name, class, teacherID, teacher_name, email) VALUES ('$subjectName', '$class', '$teacherID', '$teacherName', '$teacherEmail')";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Subject registered successfully";
        } else {
            $error = "Error registering subject: " . $conn->error;
        }
    } else {
        $error = "Error: Teacher not found.";
    }
}

// Retrieve teachers from the database
$teachers = [];
$retrieveTeachersSQL = "SELECT teacherID, CONCAT(firstname, ' ', lastname) AS full_name, email FROM teachers";
$result = $conn->query($retrieveTeachersSQL);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $teachers[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subject Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        form div {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="black" d="M10 12L5 7h10l-5 5z"/></svg>');
            background-repeat: no-repeat;
            background-position: right 10px center;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            margin-top: 10px;
        }

        .success-message {
            color: green;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Subject Registration</h1>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div>
                <label for="subjectName">Subject Name:</label>
                <input type="text" id="subjectName" name="subjectName" required>
            </div>
            <div>
                <label for="class">Class:</label>
                <select id="class" name="class" required>
                    <option value="" disabled selected>Select Class</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                </select>
            </div>
            <div>
                <label for="teacher">Teacher:</label>
                <select id="teacher" name="teacher" required>
                    <option value="" disabled selected>Select Teacher</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?php echo $teacher['full_name']; ?>"><?php echo $teacher['full_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit">Register Subject</button>
        </form>

        <?php
        // Display error or success message
        if (!empty($error)) {
            echo "<p class='error-message'>Error: $error</p>";
        } elseif (!empty($success_message)) {
            echo "<p class='success-message'>$success_message</p>";
        }
        ?>
    </div>
</body>
</html>
