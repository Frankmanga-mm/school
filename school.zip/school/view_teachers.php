<?php
// Include session.php and database.php
include 'session.php';
include 'database.php';

// Fetch teachers data from the database based on search criteria
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $sql = "SELECT * FROM teachers WHERE firstname LIKE '%$search%' OR lastname LIKE '%$search%' OR username LIKE '%$search%'";
} else {
    // If no search term provided, fetch all teachers
    $sql = "SELECT * FROM teachers";
}

$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Teachers</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Include Font Awesome -->
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
  }

  h2 {
    text-align: center;
  }

  table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  table th, table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
  }

  table th {
    background-color: #f2f2f2;
  }

  table td {
    vertical-align: middle;
  }

  table td img {
    max-width: 50px;
    max-height: 50px;
    border-radius: 50%;
  }

  table td a {
    margin-right: 10px;
    color: #007bff;
  }

  table td a:hover {
    color: #0056b3;
  }

  .search-form {
    text-align: center;
    margin-bottom: 20px;
  }

  .search-input {
    padding: 8px;
    width: 300px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-right: 10px;
  }

  .search-button {
    padding: 8px 16px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  .search-button:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<h2>View Teachers</h2>

<div class="search-form">
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
    <input type="text" name="search" class="search-input" placeholder="Search by username or full name" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
    <button type="submit" class="search-button">Search</button>
  </form>
</div>

<table>
  <thead>
    <tr>
      <th>S/NO</th>
      <th>Full Name</th>
      <th>Username</th>
      <th>Picture</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
  if ($result->num_rows > 0) {
      $sno =1;
      while ($row = $result->fetch_assoc()) {
          ?>
          <tr>
              <td><?php echo $sno ?></td>
            <td><?php echo $row['firstname'] . ' ' . $row['lastname']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><img src="teacher_uploads/<?php echo $row['picture']; ?>" alt="Teacher Picture" style="width: 50px; height: 50px;"></td>
            <td>
              <a href="edit_teacher.php?teacherID=<?php echo $row['teacherID']; ?>"><i class="fas fa-edit" title="Edit"></i></a>
              <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $row['teacherID']; ?>)"><i class="fas fa-trash-alt" title="Delete"></i></a>
            </td>
          </tr>
          <?php
          $sno++;
      }
  } else {
      echo "<tr><td colspan='5'>No teachers found.</td></tr>";
  }
  ?>
  </tbody>
</table>

<script>
  function confirmDelete(teacherID) {
    var confirmation = confirm("Are you sure you want to delete this teacher?");
    if (confirmation) {
      window.location.href = "delete_teacher.php?teacherID=" + teacherID;
    }
  }
</script>

</body>
</html>
