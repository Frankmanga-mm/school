<?php
include 'session.php';
// Include the database connection file
include 'database.php';

// Retrieve events from the database
$events_query = "SELECT * FROM events";
$events_result = $conn->query($events_query);

// Initialize serial number counter
$serial_number = 1;
?>

<?php
// Include the database connection file
include 'database.php';

// Retrieve events from the database
$events_query = "SELECT * FROM events";
$events_result = $conn->query($events_query);

// Initialize serial number counter
$serial_number = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Events</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Add your CSS styles here */
        body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    margin: 0;
    padding: 0;
    height: 40vh; /* Make the body take up the full viewport height */
    display: flex; /* Use flexbox for centering the container vertically */
    justify-content: center; /* Center the container horizontally */
    align-items: center; /* Center the container vertically */
}

.container {
    width: 1900px;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    overflow-x: auto; /* Add horizontal scroll if necessary */
}

.back-to-dashboard {
    background-color: #4CAF50;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    text-decoration: none;
    position: fixed; /* Position the button fixed to stay outside the container */
    top: 20px;
    left: 20px;
}

.back-to-dashboard:hover {
    background-color: #45a049;
}

h2 {
    text-align: center;
    color: #333;
    position: relative; /* Add position relative to make the pseudo-element positioned relative to the h2 */
}

h2::after {
    content: ''; /* Empty content for the pseudo-element */
    display: block; /* Make it a block-level element */
    width: 100%; /* Make it full width */
    height: 3px; /* Set the height of the underline */
    background-color: #36533c; /* Color of the underline */
    position: absolute; /* Position it absolutely */
    bottom: -5px; /* Adjust the position to cover the bottom border of the h2 */
    left: 0; /* Align it to the left */
}

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .actions {
            text-align: center;
            
    
        }
        .edit-btn i,
        .delete-btn i,
        .delete-btn i {
        margin-right: 5px; /* Add space between icon and text */
        }
        .actions a{
            text-decoration : none;
            font-size : 16px;
            font-family : Times New Roman;
           
        }

        .edit-btn, .delete-btn, .view-btn {
            padding: 7px;
            margin-right: 5px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .delete-btn {
            background-color: #f44336;
          
        }
        .view-btn {
            background-color: blue;
        }
    </style>
</head>
<body>
<a href="dashboard.php" class="back-to-dashboard">Back to Dashboard</a>

    <div class="container">
        <h2>History of All Time Events  |   Historia ya Matukio Yote</h2>
        <?php if ($events_result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>S/No</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Location</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Loop through each event and display its details in a row
                while($event_row = $events_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $serial_number . "</td>";
                    echo "<td>" . $event_row['title'] . "</td>";
                    echo "<td>" . $event_row['date'] . "</td>";
                    echo "<td>" . $event_row['time'] . "</td>";
                    echo "<td>" . $event_row['location'] . "</td>";
                    echo "<td>" . $event_row['description'] . "</td>";
                    echo "<td class='actions'>";
                    echo "<a href='edit_event.php?eventID=" . $event_row['eventID'] . "' class='edit-btn'><i class='fas fa-edit'></i>Edit</a>";
                    echo "<a href='delete_event.php?eventID=" . $event_row['eventID'] . "' class='delete-btn' onclick='return confirmDelete()'><i class='fas fa-trash-alt'></i>Delete</a>";
                    echo "<a href='view_event_details.php?eventID=" . $event_row['eventID'] . "' class='view-btn'><i class='fas fa-eye'></i>View</a>";

                    echo "</td>";
                    echo "</tr>";
                    // Increment the serial number counter
                    $serial_number++;
                }
                ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No results found.</p>
        <?php endif; ?>
    </div>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this event?");
        }
    </script>
</body>
</html>

