<?php
include 'session.php';
include 'database.php';

// Initialize variables to store selected class, semester, and month
$selected_class = $selected_semester = $selected_month = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve selected class from the form
    $selected_class = $_POST['class'];
    // Construct the table name based on the selected class
    $table_name = 'std' . $selected_class . '_results';

    // Retrieve selected semester and month from the form
    $selected_semester = $_POST['semester'];
    $selected_month = $_POST['month'];

    // Fetch and display student results only if all selections are made
    if (!empty($selected_class) && !empty($selected_semester) && !empty($selected_month)) {
        // Query to retrieve semester and month values from the database
        $semester_month_query = "SELECT DISTINCT semester, month FROM $table_name";
        $semester_month_result = $conn->query($semester_month_query);

        // Check if query was successful
        if ($semester_month_result && $semester_month_result->num_rows > 0) {
            // Fetch semester and month options
            $semesters = $semester_month_result->fetch_all(MYSQLI_ASSOC);
            $months = array_column($semesters, 'month');
            $semesters = array_column($semesters, 'semester');
        }

        // Fetch student results for the selected class, semester, and month
        $sql_results = "SELECT * FROM $table_name WHERE semester = '$selected_semester' AND month = '$selected_month' ORDER BY average DESC";
        $result_results = $conn->query($sql_results);

        // Check if query was successful
        if ($result_results && $result_results->num_rows > 0) {
            // Display results table
            echo "<div class='container'>";
            echo "<h2>Student Results</h2>";
            echo "<table>";
            echo "<thead>";
            echo "<tr>";
            echo "<th>S/NO</th>";
            echo "<th>Full Name</th>";
            echo "<th>Kiswahili</th>";
            echo "<th>English</th>";
            echo "<th>History</th>";
            echo "<th>Science</th>";
            echo "<th>Mathematics</th>";
            echo "<th>Total Marks</th>";
            echo "<th>Average</th>";
            echo "<th>Grade</th>";
            echo "<th>Position</th>";
            echo "<th>Semester</th>";
            echo "<th>Month</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
            
            $sno = 1;
            // Loop through the results to display student details and calculate totals, average, grade, and position
            while ($row = $result_results->fetch_assoc()) {
                // Calculate total marks
                $total_marks = $row['kiswahili'] + $row['english'] + $row['history'] + $row['science'] + $row['mathematics'];
                // Calculate average
                $average = $total_marks / 5;
                // Calculate grade
                if ($average >= 80) {
                    $grade = 'A';
                } elseif ($average >= 60) {
                    $grade = 'B';
                } elseif ($average >= 40) {
                    $grade = 'C';
                } elseif ($average >= 21) {
                    $grade = 'D';
                } else {
                    $grade = 'F';
                }

                // Display the student details in the table row
                echo "<tr>";
                echo "<td>$sno</td>";
                echo "<td>{$row['fullname']}</td>";
                echo "<td>{$row['kiswahili']}</td>";
                echo "<td>{$row['english']}</td>";
                echo "<td>{$row['history']}</td>";
                echo "<td>{$row['science']}</td>";
                echo "<td>{$row['mathematics']}</td>";
                echo "<td>" . number_format($total_marks, 1) . "</td>";
                echo "<td>" . number_format($average, 1) . "</td>";
                echo "<td>$grade</td>";
                
                // Calculate position
                $position_query = "SELECT COUNT(*) AS position FROM $table_name WHERE semester = '$selected_semester' AND month = '$selected_month' AND average > $average";
                $position_result = $conn->query($position_query);
                if ($position_result && $position_row = $position_result->fetch_assoc()) {
                    $position = $position_row['position'] + 1;
                    echo "<td>$position</td>";
                } else {
                    echo "<td>N/A</td>";
                }
                
                echo "<td>{$row['semester']}</td>";
                echo "<td>{$row['month']}</td>";
                echo "</tr>";
                $sno++;
            }

            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } else {
            // If no results found, display message
            echo "<div class='container'>";
            echo "<h2>Student Results</h2>";
            echo "<p>No results found for Class $selected_class, Semester $selected_semester, Month $selected_month</p>";
            echo "</div>";
        }
    } else {
        // If any of the selections are empty, display a message
        echo "<div class='container'>";
        echo "<h2>Student Results</h2>";
        echo "<p>Please select Class, Semester, and Month</p>";
        echo "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <style>
        <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 1500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-right: 10px;
            font-size: 16px;
        }

        select {
            padding: 8px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: #fff;
        }

        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        p {
            text-align: center;
            color: #333;
        }

        @media only screen and (max-width: 768px) {
            .container {
                padding: 10px;
            }
        }
    </style>
    </style>
</head>
<body>
<div class="container">
    <h2>View Student Results</h2>
    <!-- Form for selecting class, semester, and month -->
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <!-- Select Class -->
        <label for="class">Select Class:</label>
        <select id="class" name="class" required>
            <option value="" disabled <?php if (empty($selected_class)) echo "selected"; ?>>Select Class</option>
            <?php for ($i = 1; $i <= 7; $i++) : ?>
                <option value="<?php echo $i; ?>" <?php if ($selected_class == $i) echo "selected"; ?>><?php echo "Class $i"; ?></option>
            <?php endfor; ?>
        </select>

        <!-- Select Semester -->
        <label for="semester">Select Semester:</label>
        <select id="semester" name="semester" required>
            <option value="" disabled <?php if (empty($selected_semester)) echo "selected"; ?>>Select Semester</option>
            <option value="Mid Term" <?php if ($selected_semester == "Mid Term") echo "selected"; ?>>Mid Term</option>
            <option value="Annually" <?php if ($selected_semester == "Annually") echo "selected"; ?>>Annually</option>
            <option value="Semi-Annually" <?php if ($selected_semester == "Semi-Annually") echo "selected"; ?>>Semi-Annually</option>
        </select>

        <!-- Select Month -->
        <label for="month">Select Month:</label>
        <select id="month" name="month" required>
            <option value="" disabled <?php if (empty($selected_month)) echo "selected"; ?>>Select Month</option>
            <?php
            $months = array(
                "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
            );

            foreach ($months as $month) {
                echo "<option value='$month' " . ($selected_month == $month ? "selected" : "") . ">$month</option>";
            }
            ?>
        </select>

        <button type="submit" name="submit">Submit</button>
    </form>
</div>
</body>
</html>
