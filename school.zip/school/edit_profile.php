<?php
// Include session and database files
include 'session.php';
include 'database.php';

// Initialize variables to store teacher data
$id = $teacherUsername = $teacherEmail = $teacherPicture = '';

// Check if session variable is set
if(isset($_SESSION['teacherID'])) {
    $id = $_SESSION['teacherID'];

    // Retrieve teacher data from the database
    $sql = "SELECT * FROM teachers WHERE teacherID = '$id'";
    $result = $conn->query($sql);

    // Check if query was successful and if data exists
    if($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $teacherUsername = $row['username'];
        $teacherEmail = $row['email'];
        $teacherPicture = $row['picture'];
    } else {
        echo "No teacher data found.";
        exit(); // Exit script if no data found
    }
} else {
    echo "Teacher ID not set in session.";
    exit(); // Exit script if session variable not set
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
       body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
  }

  .header {
    background-color: #6d6363c2;
    color: #fff;
    margin-left : 0px;
    padding: 10px;
    text-align: center;
  }
  .header h1{
    margin-left : 0px;
    font-size : 16px;
    font-type : Times New Roman;
    padding: 10px;
    text-align: center;
  }

  .main-content {
    margin-left: ; /* Same width as the sidebar */
    padding: 10px;
    max-height: 70vh; /* Maximum height of the main content */
  }
  h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size : 16px;
    font-type : Times New Roman;
  }

  .profile {
  text-align: center;
  background-color:#d7dddbc2;

  border: 2px solid #ccc; /* Add border around the profile */
  border-radius: 10px;
  padding: 16px; /* Reduced padding */
  margin-bottom: 20px;
  margin-left: 400px;
  margin-right: 400px;
  margin-bottom: 20px;

}

.profile form {
  display: flex;
  flex-direction: column;
  background-color:#6d6363c2;
  align-items: center;
  border: 2px solid #ccc; /* Add border around the form */
  border-radius: 10px;
  padding: 10px; /* Reduced padding */
  margin: 5px;
}
  .profile img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    margin-bottom: 20px;
  }

  .profile p {
    margin-bottom: 10px;
    
  }

  .profile form h2 {
    margin-top: 0; /* Remove default margin from h2 */
    margin-bottom: 16px;
    font-size : 16px;
    font-type : Times New Roman;
  }

  .profile input[type="text"],
  .profile input[type="email"],
  .profile input[type="file"],
  .profile input[type="submit"] {
    margin-bottom: 10px;
  }

    </style>
</head>
<body>

<div class="header">
    <h1>Welcome, <?php echo $teacherUsername; ?></h1>
</div>

<div class="main-content">
    <h2>Teacher Profile</h2>
    <div class="profile">
        <img src="uploads/<?php echo $teacherPicture; ?>" alt="Profile Picture">
        <p>Username: <?php echo $teacherUsername; ?></p>
        <p>Email: <?php echo $teacherEmail; ?></p>

        <form action="edit_profile.php" method="post" enctype="multipart/form-data">
            <h2>Update Profile</h2>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="text" name="username" placeholder="Username" value="<?php echo $teacherUsername; ?>">
            <input type="email" name="email" placeholder="Email" value="<?php echo $teacherEmail; ?>">
            <input type="file" name="picture" accept="image/*">
            <input type="submit" value="Update Profile" name="update_profile">
        </form>
    </div>
</div>

</body>
</html>

<?php
// Include database file
include 'database.php';

// Check if form is submitted for updating profile
if(isset($_POST['update_profile'])) {
    // Get form data
    $id = $_POST['id'];
    $newUsername = $_POST['username'];
    $newEmail = $_POST['email'];

    // Fetch existing picture from the database
    $sql = "SELECT picture FROM teachers WHERE teacherID = '$id'";
    $result = $conn->query($sql);

    // Check if query was successful
    if($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $existingPicture = $row['picture'];

        // Check if a new picture is uploaded
        if ($_FILES['picture']['name']) {
            // Handle picture upload
            $target_dir = "teacher_uploads/";
            $target_file = $target_dir . basename($_FILES["picture"]["name"]);
            if(move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
                $newPicture = basename($_FILES["picture"]["name"]);
            } else {
                echo "Failed to move uploaded file.";
                exit();
            }
        } else {
            // Keep the existing picture
            $newPicture = $existingPicture;
        }

        // Update profile in the database using prepared statement to prevent SQL injection
        $updateSql = "UPDATE teachers SET username=?, email=?, picture=? WHERE teacherID=?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("sssi", $newUsername, $newEmail, $newPicture, $id);

        // Execute the update query
        if ($stmt->execute()) {
            // Redirect to profile page with success message
            header("Location: edit_profile.php?update=success");
            exit();
        } else {
            // Redirect to profile page with error message
            header("Location: edit_profile.php?update=error");
            exit();
        }
    } else {
        echo "No teacher data found for ID: $id";
        exit();
    }
}
?>
