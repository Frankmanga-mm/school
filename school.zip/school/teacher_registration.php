<?php
include 'session.php';
// Include the database connection file
include 'database.php';

// Initialize error variable
$error = "";
$success_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Check if passwords match
    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        // Prepare SQL statement to check if the email already exists
        $checkEmailSQL = "SELECT * FROM teachers WHERE email = '$email'";

        // Execute the SQL statement
        $result = $conn->query($checkEmailSQL);

        // Check if the email already exists
        if ($result->num_rows > 0) {
            $error = "Email already exists.";
        } else {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Check if a file is selected
            if ($_FILES['picture']['name']) {
                // File upload path
                $targetDir = "teacher_uploads/";
                $fileName = basename($_FILES["picture"]["name"]);
                $targetFilePath = $targetDir . $fileName;
                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                // Allow certain file formats
                $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');
                if (in_array($fileType, $allowedTypes)) {
                    // Upload file to server
                    if (move_uploaded_file($_FILES["picture"]["tmp_name"], $targetFilePath)) {
                        // File uploaded successfully
                        //$success_message .= "Profile picture uploaded successfully.";
                    } else {
                        $error .= "Sorry, there was an error uploading your file.";
                    }
                } else {
                    $error .= "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
                }
            }

            // Prepare SQL statement to insert data into the database
            $sql = "INSERT INTO teachers (firstname, lastname, username, email, password, picture) VALUES ('$firstName', '$lastName', '$username', '$email', '$hashedPassword', '$fileName')";

            // Execute the SQL statement
            if ($conn->query($sql) === TRUE) {
                $success_message .= "New record created successfully";
                // Clear form fields
                $_POST = array();
            } else {
                $error = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Registration</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Include Font Awesome -->
<style>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
  }
  
  .container {
    max-width: 500px;
    margin: 50px auto;
    background-color: #ffffff; /* Changed background color for the form */
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    border: 1px solid #ccc; /* Added border around the form */
  }
  
  .header-container {
    background-color: grey; /* Background color for the header container */
    border-radius: 10px 10px 0 0; /* Rounded corners for the top */
    padding: 20px;
    margin-bottom: 20px;
  }
  
  h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #ffffff; /* Changed text color for the heading */
  }
  
  .form-group {
    margin-bottom: 20px;
    position: relative;
  }
  
  input[type="text"],
  input[type="password"],
  input[type="email"],
  input[type="file"] {
    width: calc(100% - 40px); /* Adjusted width to accommodate icon */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #f5f5f5; /* Added background color for input fields */
    padding-left: 35px; /* Added space for the icon */
  }

  input[type="text"],
  input[type="password"],
  input[type="email"] {
    color: #333333; /* Changed text color */
  }

  input[type="text"]::placeholder,
  input[type="password"]::placeholder,
  input[type="email"]::placeholder {
    color: #999999; /* Changed placeholder color */
  }
  
  .fa {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: 10px;
    color: #999999; /* Icon color */
  }
  
  input[type="submit"] {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #007bff;
    color: #ffffff; /* Changed text color */
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  input[type="submit"]:hover {
    background-color: #0056b3;
  }

  .error-message {
    color: red;
    font-size: 14px;
  }

  .success-message {
    color: green;
    font-size: 14px;
  }
</style>
</style>
</head>
<body>

<div class="container">
  <div class="header-container">
    <h2>Teacher Registration</h2>
  </div>
  
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <input type="text" id="firstName" name="firstName" placeholder="First Name" value="<?php echo isset($_POST['firstName']) ? $_POST['firstName'] : ''; ?>" required>
    </div>
    <div class="form-group">
      <input type="text" id="lastName" name="lastName" placeholder="Last Name" value="<?php echo isset($_POST['lastName']) ? $_POST['lastName'] : ''; ?>" required>
    </div>
    <div class="form-group">
      <input type="text" id="username" name="username" placeholder="Username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>" required>
    </div>
    <div class="form-group">
      <input type="email" id="email" name="email" placeholder="Email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" required>
    </div>
    <div class="form-group">
      <input type="file" id="picture" name="picture" accept="image/*" required>
    </div>
    <div class="form-group">
      <input type="password" id="password" name="password" placeholder="Password" required>
    </div>
    <div class="form-group">
      <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required>
      <span class="error-message"><?php echo $error; ?></span>
      <span class="success-message"><?php echo $success_message; ?></span>
    </div>

    <input type="submit" value="Register" name="register">
  </form>
</div>

</body>
</html>


