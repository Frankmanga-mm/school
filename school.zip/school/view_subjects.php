<?php
// Include session.php and database.php
include 'session.php';
include 'database.php';

// Fetch subjects data from the database
$sql = "SELECT subjects.*, teachers.email AS email FROM subjects 
        LEFT JOIN teachers ON subjects.teacherID = teachers.teacherID";

// Check if search query is provided
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $sql .= " WHERE subject_name LIKE '%$search%' OR class LIKE '%$search%' OR email LIKE '%$search%'";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Subjects</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Include Font Awesome -->
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
  }

  h2 {
    text-align: center;
  }

  table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  table th, table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
  }

  table th {
    background-color: #f2f2f2;
  }

  table td {
    vertical-align: middle;
  }

  table td a {
    margin-right: 10px;
    color: #007bff;
  }

  table td a:hover {
    color: #0056b3;
  }

  .search-container {
    text-align: center;
    margin-bottom: 20px;
  }

  .search-input {
    padding: 8px;
    width: 300px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-right: 10px;
  }

  .search-button {
    padding: 8px 16px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  .search-button:hover {
    background-color: #0056b3;
  }
</style>
</head>
<body>

<h2>View Subjects</h2>

<div class="search-container">
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
    <input type="text" name="search" class="search-input" placeholder="Search...">
    <button type="submit" class="search-button"><i class="fas fa-search"></i></button>
  </form>
</div>

<table>
  <thead>
    <tr>
      <th>S/NO</th>
      <th>Teacher Name</th>
      <th>Subject</th>
      <th>Class</th>
      <th>Email</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $sno = 1; // Initialize serial number counter
  if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
          ?>
          <tr>
            <td><?php echo $sno++; ?></td>
            <td><?php echo $row['teacher_name']; ?></td>
            <td><?php echo $row['subject_name']; ?></td>
            <td><?php echo $row['class']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td>
              <a href="edit_subject.php?subject_id=<?php echo $row['subject_id']; ?>"><i class="fas fa-edit" title="Edit"></i></a>
              <a href="delete_subjects.php?subject_id=<?php echo $row['subject_id']; ?>"><i class="fas fa-trash-alt" title="Delete"></i></a>
            </td>
          </tr>
          <?php
      }
  } else {
      echo "<tr><td colspan='6'>No subjects found.</td></tr>";
  }
  ?>
  </tbody>
</table>

</body>
</html>
