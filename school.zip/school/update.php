<?php
include 'session.php';

// Include the database connection file
include 'database.php';

if(isset($_POST['update'])) {
    // Get the values from the form
    $id = $_POST['id'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $class = $_POST['class'];
    $phone = $_POST['phone'];
    $picture = $_POST['picture'];
    $dateOfBirth = $_POST['dateOfBirth'];

    // Update the record in the database
    $sql = "UPDATE students SET 
            firstname = '$firstname',
            middlename = '$middlename',
            lastname = '$lastname',
            gender = '$gender',
            class = '$class',
            phone = '$phone',
            picture = '$picture',
            dateOfBirth = '$dateOfBirth'
            WHERE studentID = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the view students page after updating
        header("Location: view.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "No update request received.";
}
?>
