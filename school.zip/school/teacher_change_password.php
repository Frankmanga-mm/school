<?php
include 'session.php'; // Include the session file for session management
include 'database.php'; // Include the database connection file

// Initialize error and success messages
$error = "";
$success_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $oldPassword = $_POST['oldPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmNewPassword = $_POST['confirmNewPassword'];

    // Validate form inputs
    if (empty($oldPassword) || empty($newPassword) || empty($confirmNewPassword)) {
        $error = "All fields are required.";
    } elseif ($newPassword !== $confirmNewPassword) {
        $error = "New password and confirm password do not match.";
    } else {
        // Check if the old password matches the one in the database
        $teacherID = $_SESSION['teacherID']; // Assuming user ID is stored in the session
        $checkPasswordSQL = "SELECT password FROM teachers WHERE teacherID = '$teacherID'";
        $result = $conn->query($checkPasswordSQL);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $hashedPassword = $row['password'];

            if (password_verify($oldPassword, $hashedPassword)) {
                // Hash the new password
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update the password in the database
                $updatePasswordSQL = "UPDATE teachers SET password = '$hashedNewPassword' WHERE teacherID= '$teacherID'";
                if ($conn->query($updatePasswordSQL) === TRUE) {
                    header("refresh:1;url=teacher_login.php");
                } else {
                    $error = "Error updating password: " . $conn->error;
                }
            } else {
                $error = "Old password is incorrect.";
            }
        } else {
            $error = "User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border: 1px solid #ccc;
        }

        .header-container {
            background-color: #007bff;
            border-radius: 8px 8px 0 0;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        h2 {
            margin: 0;
            color: #ffffff;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        input[type="password"] {
            width: calc(100% - 40px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            background-color: #f5f5f5;
            padding-left: 35px;
            transition: border-color 0.3s ease;
        }

        input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
        }

        .fa {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            left: 10px;
            color: #999999;
        }

        .error-message,
        .success-message {
            display: block;
            margin-top: 5px;
            font-size: 14px;
        }

        .error-message {
            color: red;
        }

        .success-message {
            color: green;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #ffffff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header-container">
        <h2>Change Password</h2>
    </div>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <div class="form-group">
            <i class="fa fa-lock"></i>
            <input type="password" id="oldPassword" name="oldPassword" placeholder="Old Password" required>
        </div>
        <div class="form-group">
            <i class="fa fa-lock"></i>
            <input type="password" id="newPassword" name="newPassword" placeholder="New Password" required>
        </div>
        <div class="form-group">
            <i class="fa fa-lock"></i>
            <input type="password" id="confirmNewPassword" name="confirmNewPassword" placeholder="Confirm New Password" required>
            <span class="error-message"><?php echo $error; ?></span>
            <span class="success-message"><?php echo $success_message; ?></span>
        </div>

        <input type="submit" value="Change Password" name="changePassword">
    </form>
</div>

</body>
</html>

