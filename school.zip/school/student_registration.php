<?php


include 'session.php';


// Include the database connection file
include 'database.php';

// Initialize error variable
$error = "";
$success_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $gender = $_POST['gender'];
    $phoneNumber = $_POST['phoneNumber'];
    $username = $_POST['username'];
    $dateOfBirth = $_POST['dateOfBirth'];
    $class = $_POST['class'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // File upload handling
$picture = $_FILES['picture']['name'];
$target_dir = "uploads/"; // Directory where the file will be stored
$target_file = $target_dir . basename($_FILES["picture"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Check file type
$allowedExtensions = array("jpg", "jpeg", "png", "gif");
if (!in_array($imageFileType, $allowedExtensions)) {
    $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
    $uploadOk = 0;
}

// Check file size (maximum 5MB)
$maxFileSize = 5 * 1024 * 1024; // 5 MB in bytes
if ($_FILES["picture"]["size"] > $maxFileSize) {
    $error = "Sorry, your file is too large. Maximum file size allowed is 5MB.";
    $uploadOk = 0;
}

// Proceed with file upload if everything is OK
if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
        // File uploaded successfully
    } else {
        $error = "Sorry, there was an error uploading your file.";
    }
}

    // Check if passwords match
    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement to check if the username already exists
        $checkUsernameSQL = "SELECT * FROM students WHERE username = '$username'";

        // Execute the SQL statement
        $result = $conn->query($checkUsernameSQL);

        // Check if the username already exists
        if ($result->num_rows > 0) {
            $error = "Username already exists.";
        } else {
            // Prepare SQL statement to insert data into the database
            $sql = "INSERT INTO students (firstname, middlename, lastname, gender, phone, username, dateOfbirth, picture, class, password) VALUES ('$firstName', '$middleName', '$lastName', '$gender', '$phoneNumber', '$username', '$dateOfBirth', '$picture', '$class', '$hashedPassword')";

            // Execute the SQL statement
            if ($conn->query($sql) === TRUE) {
                $success_message = "New record created successfully";
                // Clear form fields
                $_POST = array();

                // Redirect to dashboard
                header("refresh:1; url = view.php");
                exit(); // stop further execution
            } else {
                $error = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

.container {
   max-width: 1400px; /* Adjusted width to fit the screen */
   
    margin: 50px auto;
    background-color: #ffffff; /* Changed background color for the form */
    border-radius: 30px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    padding: 50px;
    border: 1px solid #ccc; /* Added border around the form */
    position: relative;
}

.header-container {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
}

.logo img {
    max-width: 150px; /* Adjust the size as needed */
    border-radius: 8px; /* Added border-radius for rounded corners */
}

.title h2 {
    margin-left: 20px; /* Adjust the spacing between the image and the text */
    font-family: "Times New Roman", Times, serif; /* Changed font type */
    color: #333; /* Changed text color */
    font-size: 25px;
}

h2 {
    text-align: center;
    margin-top: 1px;
    color: #6b2121; /* Changed text color for the heading */
}

.form-group {
    margin: 10px;
}

input[type="text"],
input[type="password"],
input[type="file"],
select {
    width: calc(100% - 20px); /* Adjusted width to fit the container */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #f5f5f5; /* Added background color for input fields */
}

input[type="text"],
input[type="password"],
input[type="file"],
select {
    color: #333333; /* Changed text color */
}

input[type="text"]::placeholder,
input[type="password"]::placeholder,
input[type="file"]::placeholder,
select::placeholder {
    color: #999999; /* Changed placeholder color */
}

input[type="submit"] {
    width: calc(100% - 20px); /* Adjusted width to fit the container */
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #007bff;
    color: #ffffff; /* Changed text color */
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

img {
    display: block;
    margin: 0 auto 20px;
    max-width: 200px;
    border-radius: 1px; /* Make the image rounded */
}

.error-message {
    color: red;
    font-size: 14px;
}

.success-message {
    color: green;
    font-size: 14px;
}

button {
    background-color: #0a0e12;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    padding: 10px 20px;
    cursor: pointer;
    position: absolute;
    top: 10px;
    left: 15px;
}

button:hover {
    background-color: #6a2e26;
}

/* Media query for smaller screens */
@media (max-width: 768px) {
    .container {
        width: 90%;
        max-width: 90%;
    }
}
.separator {
    border: 1px solid green;
    border-radius :10px;
    height: 2px; /* Adjust the height of the line as needed */
    background-color: #1c61df; /* Adjust the color of the line as needed */
    margin: ; /* Adjust the margin around the line as needed */
}

    </style>
</head>
<body>

<button onclick="goBack()"><i class="fas fa-arrow-left"></i> Back to Previous Page</button>
<div class="container">
<div class="header-container">
    <div class="logo">
        <img src="images/go.jpg" alt="Student Registration">
    </div>
    <div class="title">
        <h2>Student Registration |  Usajiri wa Mwanafunzi</h2>
    </div>
</div>
<hr class="separator">

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data"> <!-- Added enctype="multipart/form-data" for file upload -->
        <div class="form-group">
            <input type="text" id="firstName" name="firstName" placeholder="First Name" value="<?php echo isset($_POST['firstName']) ? $_POST['firstName'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <input type="text" id="middleName" name="middleName" placeholder="Middle Name" value="<?php echo isset($_POST['middleName']) ? $_POST['middleName'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <input type="text" id="lastName" name="lastName" placeholder="Last Name" value="<?php echo isset($_POST['lastName']) ? $_POST['lastName'] : ''; ?>" required>
        </div>

        <div class="form-group">
            <select id="gender" name="gender" required>
                <option value="" disabled selected hidden>Select Gender</option> <!-- Added hidden default option -->
                <option value="Male" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>


        <div class="form-group">
            <input type="text" id="username" name="username" placeholder="Username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>" required>
        </div>
        <div class="form-group">
            <input type="date" id="dateOfBirth" name="dateOfBirth" placeholder="Date of Birth" value="<?php echo isset($_POST['dateOfBirth']) ? $_POST['dateOfBirth'] : ''; ?>" required> <!-- Added Date of Birth field -->
        </div>
        <div class="form-group">
            <input type="text" id="phoneNumber" name="phoneNumber" placeholder="Phone Number" value="<?php echo isset($_POST['phoneNumber']) ? $_POST['phoneNumber'] : ''; ?>" required> <!-- Added phone number field -->
        </div>
        <div class="form-group">
            <input type="file" id="picture" name="picture" accept="image/*" required> <!-- Added file input for picture upload -->
        </div>
        <div class="form-group">
    <select id="class" name="class" required>
        <option value="" disabled selected hidden>Select Class</option>
        <option value="1" <?php echo isset($_POST['class']) && $_POST['class'] == '1' ? 'selected' : ''; ?>>1</option>
        <option value="2" <?php echo isset($_POST['class']) && $_POST['class'] == '2' ? 'selected' : ''; ?>>2</option>
        <option value="3" <?php echo isset($_POST['class']) && $_POST['class'] == '3' ? 'selected' : ''; ?>>3</option>
        <option value="4" <?php echo isset($_POST['class']) && $_POST['class'] == '4' ? 'selected' : ''; ?>>4</option>
        <option value="5" <?php echo isset($_POST['class']) && $_POST['class'] == '5' ? 'selected' : ''; ?>>5</option>
        <option value="6" <?php echo isset($_POST['class']) && $_POST['class'] == '6' ? 'selected' : ''; ?>>6</option>
        <option value="7" <?php echo isset($_POST['class']) && $_POST['class'] == '7' ? 'selected' : ''; ?>>7</option>
    </select>
</div>

        <div class="form-group">
            <input type="password" id="password" name="password" placeholder="Password" required>
        </div>
        <div class="form-group">
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required>
            <span class="error-message"><?php echo $error; ?></span>
            <span class="success-message"><?php echo $success_message; ?></span>
        </div>

        <input type="submit" value="Register" name="register">

    </form>
</div>
<script>
    // JavaScript function to navigate back to the previous page
    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>

