-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2024 at 09:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance1`
--

CREATE TABLE `attendance1` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance1`
--

INSERT INTO `attendance1` (`id`, `teacherID`, `studentID`, `subject_id`, `attendance_status`, `uploaded_date`, `created_at`) VALUES
(7, 16, 33, 34, 'Present', '2024-05-09', '2024-05-01 06:59:16'),
(8, 16, 34, 34, 'Present', '2024-05-09', '2024-05-01 06:59:16'),
(9, 16, 35, 34, 'Present', '2024-05-09', '2024-05-01 06:59:16'),
(10, 16, 33, 34, 'Present', '2024-05-18', '2024-05-01 07:00:47'),
(11, 16, 34, 34, 'Present', '2024-05-18', '2024-05-01 07:00:47'),
(12, 16, 35, 34, 'Present', '2024-05-18', '2024-05-01 07:00:48'),
(13, 16, 33, 34, 'Permission', '2024-05-23', '2024-05-01 08:54:45'),
(14, 16, 34, 34, 'Present', '2024-05-23', '2024-05-01 08:54:45'),
(15, 16, 35, 34, 'Absent', '2024-05-23', '2024-05-01 08:54:45');

-- --------------------------------------------------------

--
-- Table structure for table `attendance2`
--

CREATE TABLE `attendance2` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance3`
--

CREATE TABLE `attendance3` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance4`
--

CREATE TABLE `attendance4` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance5`
--

CREATE TABLE `attendance5` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance5`
--

INSERT INTO `attendance5` (`id`, `teacherID`, `studentID`, `subject_id`, `attendance_status`, `uploaded_date`, `created_at`) VALUES
(1, 16, 45, 48, 'Present', '2024-05-10', '2024-05-01 07:29:16'),
(2, 16, 46, 48, 'Absent', '2024-05-10', '2024-05-01 07:29:17'),
(3, 16, 47, 48, 'Permission', '2024-05-10', '2024-05-01 07:29:17');

-- --------------------------------------------------------

--
-- Table structure for table `attendance6`
--

CREATE TABLE `attendance6` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance7`
--

CREATE TABLE `attendance7` (
  `id` int(11) NOT NULL,
  `teacherID` int(11) DEFAULT NULL,
  `studentID` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_status` varchar(255) DEFAULT NULL,
  `uploaded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eventID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `resultID` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `geography` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` int(11) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `std1_results`
--

CREATE TABLE `std1_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` decimal(11,0) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `std1_results`
--

INSERT INTO `std1_results` (`result_id`, `studentID`, `fullname`, `kiswahili`, `history`, `science`, `english`, `mathematics`, `total_marks`, `average`, `grade`, `position`, `semester`, `month`) VALUES
(114, 33, 'Amosi John Johnathani', 34, 45, NULL, NULL, NULL, 79, 15.80, 'F', 3, 'Monthly', 'January'),
(115, 34, 'Deogrtius Shayo kazana', 44, 45, NULL, NULL, NULL, 89, 17.80, 'F', 1, 'Monthly', 'January'),
(116, 35, 'Feilicia Morice kazana', 34, 34, NULL, NULL, NULL, 68, 13.60, 'F', 4, 'Monthly', 'January'),
(117, 54, 'JOHN Shayo Shayo', 66, 23, NULL, NULL, NULL, 89, 17.80, 'F', 2, 'Monthly', 'January'),
(118, 33, 'Amosi John Johnathani', 45, 45, NULL, NULL, NULL, 90, 18.00, 'F', 4, 'Annually', 'December'),
(119, 34, 'Deogrtius Shayo kazana', 66, 87, NULL, NULL, NULL, 153, 30.60, 'D', 1, 'Annually', 'December'),
(120, 35, 'Feilicia Morice kazana', 55, 88, NULL, NULL, NULL, 143, 28.60, 'D', 2, 'Annually', 'December'),
(121, 54, 'JOHN Shayo Shayo', 66, 77, NULL, NULL, NULL, 143, 28.60, 'D', 3, 'Annually', 'December');

-- --------------------------------------------------------

--
-- Table structure for table `std2_results`
--

CREATE TABLE `std2_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(5) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `std2_results`
--

INSERT INTO `std2_results` (`result_id`, `studentID`, `fullname`, `kiswahili`, `history`, `science`, `english`, `mathematics`, `total_marks`, `average`, `grade`, `position`, `semester`, `month`) VALUES
(10, 37, 'Claudi kazana', 45, NULL, 56, 45, 56, 202, 40.40, 'C', 1, NULL, NULL),
(11, 38, 'Devotha kazana', 56, 45, NULL, 56, 45, 202, 40.40, 'C', 1, NULL, NULL),
(12, 36, 'Emmanuel kazana', 56, 12, 67, NULL, 23, 158, 31.60, 'D', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `std3_results`
--

CREATE TABLE `std3_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `std4_results`
--

CREATE TABLE `std4_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `std5_results`
--

CREATE TABLE `std5_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `std6_results`
--

CREATE TABLE `std6_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(10,0) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `std7_results`
--

CREATE TABLE `std7_results` (
  `result_id` int(11) NOT NULL,
  `studentID` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `kiswahili` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `science` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `average` decimal(8,2) DEFAULT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentID` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateOfbirth` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentID`, `firstname`, `middlename`, `lastname`, `gender`, `username`, `dateOfbirth`, `phone`, `picture`, `class`, `role`, `password`) VALUES
(33, 'Amosi', 'John', 'Johnathani', 'Male', 'amosi', '2024-04-11', '90283773838', 'deo.jpg', '1', '0', '$2y$10$N/x/YgXU2sstfW8dGDYEN.VQBRnhU755hb.KSJGdwI7VoLIXBtoDO'),
(34, 'Deogrtius', 'Shayo', 'kazana', 'Other', 'deo', '2024-04-10', '90283773838', 'here.png', '1', '0', '$2y$10$nYHnaa8Fdt23UXth.goBMeV0UVBbLQkJEcsP7IHbfMpiNhKRW/Pra'),
(35, 'Feilicia', 'Morice', 'kazana', 'Other', 'feli', '2024-04-10', '90283773838', 'here.png', '1', '0', '$2y$10$MhPzD8Vog5IYGg0BvnUbAeStOiFB9PQReesZ1m62cls2.c29OjdyG'),
(36, 'Emmanuel', 'mlelwa', 'kazana', 'Male', 'mlelwa', '2024-04-10', '90283773838', 'here.png', '2', '0', '$2y$10$.KaXpnKtfYQvhzWqwRUtyultNvKWpy0xhm5NF16tA73g6eVR6eYWK'),
(37, 'Claudi', 'Shemdoe', 'kazana', 'Male', 'claud', '2024-04-10', '90283773838', 'here.png', '2', '0', '$2y$10$tiymCga57p/jOwj3UFmIk.f4Go.UZL8482onOXcAW0LPksitITWzu'),
(38, 'Devotha', 'Shemdoe', 'kazana', 'Male', 'devotha', '2024-04-10', '90283773838', 'here.png', '2', '0', '$2y$10$ZOkAc8wEQCRH96nJgCrwZeAd2gaaHPujVbBBTEXiQ26IrKbGd0eIC'),
(39, 'Aggnes', 'Shemdoe', 'Sponsor', 'Male', 'agness', '2024-04-10', '90283773838', 'here.png', '3', '0', '$2y$10$i8.kJ8asf2EZejcxQXHls.pFhMpbzvbrbUYHvHtF44ERVfMFqm2je'),
(40, 'Vaines', 'Deogratius', 'Sponsor', 'Male', 'vai', '2024-04-10', '90283773838', 'here.png', '3', '0', '$2y$10$Avf6YuoUHTmtn7VtrpY8yeqKsK57.WhyU5wbsOeadzKZwUETGUCDe'),
(41, 'Oscar', 'Deogratius', 'Shayo', 'Male', 'oscar', '2024-04-10', '90283773838', 'here.png', '3', '0', '$2y$10$iTadBxIf8SDk5Bj0u5Nuvu.qBJIUKXOjMGkNh7y1t3zx7UtZC0gjS'),
(42, 'OMussa', 'Mgosi', 'Shayo', 'Male', 'mussa', '2024-04-10', '90283773838', 'here.png', '4', '0', '$2y$10$5cKLlNSaAglnA/TqDp3/L.UlCg7wpk/YZq.DY936NgIweegkUQ9Mi'),
(43, 'Haruna', 'Joseph', 'Shayo', 'Male', 'haruna', '2024-04-10', '90283773838', 'here.png', '4', '0', '$2y$10$ggXuqTnpI2Jel2RXWbdpTuxUR6/E34xCv/Ebe404Zw8f6DuC3CvWq'),
(44, 'Frank', 'John', 'Shayo', 'Male', 'frank', '2024-04-10', '90283773838', 'here.png', '4', '0', '$2y$10$opGNaqdegmYi0LeVCGP.E.S8ev/s0XOQp8l1Cvz/CAHSldibyD1X6'),
(45, 'Bryson', 'John', 'Shayo', 'Male', 'bry', '2024-04-10', '90283773838', 'here.png', '5', '0', '$2y$10$TR9HLyYz/xRNy3wAVF0TYOnAn3B1MNgvpaRNB02/sFlu4wbZIETa.'),
(46, 'Elias', 'John', 'Shayo', 'Male', 'huhu', '2024-04-10', '90283773838', 'here.png', '5', '0', '$2y$10$C4nkfCjum10rQvJ0PTdDDejbjOSj7146o5GP9v.cnSz9Ki3S1FLg.'),
(47, 'Reticia', 'ff', 'Shayo', 'Male', 'huhunnn', '2024-04-10', '90283773838', 'here.png', '5', '0', '$2y$10$rvZMpWSHJG/3mKyLhiAhjeYtqwzCmVWFeoBdMdc5tySYSPY4iXneS'),
(48, 'Samweli', 'hhdfjush', 'Shayo', 'Male', 'fhfhfddj', '2024-04-10', '90283773838', 'here.png', '6', '0', '$2y$10$QGXwJX4SUWcMloxaNlU0j.KbtwOjEQHxG4MXfsFNKVBlNRENF1K6e'),
(49, 'Khamis', 'Emanuel', 'Shayo', 'Male', 'fhffjkdjfdjglkzdjzx', '2024-04-10', '90283773838', 'here.png', '6', '0', '$2y$10$x4EjMvObYluDzVHutSBGt.JFWJeMxl3Xp1C2Zu1mVaKqb/dIMgbmS'),
(50, 'Kelvin', 'Amos', 'Shayo', 'Male', 'ddedde', '2024-04-10', '90283773838', 'images (2).png', '6', '0', '$2y$10$iVgxpkI5xwnFLfijHA1oC.02YRQQ7rLCzZVXJBPmpXHRTj7y2JiMe'),
(51, 'MORICE', 'ABRAHAM', 'Shayo', 'Male', 'morice', '2024-04-10', '90283773838', 'here.png', '7', '0', '$2y$10$AO4Pt/X/FADA/GnDifP8DeImTGzg7Ulowo5HbxVgkDKfdLlDvgYO2'),
(52, 'Athanas', 'Khangi', 'Shayo', 'Male', 'athanasi', '2024-04-10', '90283773838', 'here.png', '7', '0', '$2y$10$YzH5JkMB4uNnbY0P0GSeG.p2yOMsFhpnd4qHO4GBZa5PziigoCWdW'),
(53, 'Mbagga', 'Dereva', 'mgandi', 'Male', 'mgandi', '2024-04-10', '90283773838', 'here.png', '7', '0', '$2y$10$Shx8HusfyLplIKNqGcHfXORjHlDW4vgbybHgyF1OPPMjw2nGvjBqC'),
(54, 'JOHN', 'Shayo', 'Shayo', 'Male', 'come', '2024-05-09', '90283773838', 'computer-icons-power-symbol-login-button.jpg', '1', '0', '$2y$10$9KY4YLYrRcJnvJPX83USXe8NUnpZFTGx3TpR9KdrscKis.k28dp1C');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `teacherID` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `class` int(11) NOT NULL,
  `teacher_name` varchar(255) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `teacherID`, `subject_name`, `class`, `teacher_name`, `email`) VALUES
(34, 16, 'Kiswahili', 1, 'NKATA A', 'nkata@gmail.com'),
(35, 16, 'History', 1, 'NKATA A', 'nkata@gmail.com'),
(36, 16, 'Geography', 1, 'NKATA A', 'nkata@gmail.com'),
(37, 16, 'mathematics', 1, 'NKATA A', 'nkata@gmail.com'),
(38, 16, 'science', 1, 'NKATA A', 'nkata@gmail.com'),
(39, 17, 'Kiswahili', 2, 'MANYAHII M', 'manyahi@gmail.com'),
(40, 17, 'History', 2, 'MANYAHII M', 'manyahi@gmail.com'),
(41, 17, 'Geography', 2, 'MANYAHII M', 'manyahi@gmail.com'),
(42, 17, 'mathematics', 2, 'MANYAHII M', 'manyahi@gmail.com'),
(43, 17, 'science', 2, 'MANYAHII M', 'manyahi@gmail.com'),
(44, 16, 'Kiswahili', 3, 'NKATA A', 'nkata@gmail.com'),
(45, 17, 'History', 3, 'MANYAHII M', 'manyahi@gmail.com'),
(46, 17, 'Geography', 3, 'MANYAHII M', 'manyahi@gmail.com'),
(48, 16, 'science', 5, 'NKATA A', 'nkata@gmail.com'),
(49, 16, 'science', 2, 'NKATA A', 'nkata@gmail.com'),
(50, 17, 'Kiswahili', 3, 'MANYAHII M', 'manyahi@gmail.com'),
(51, 17, 'mathematics', 7, 'MANYAHII M', 'manyahi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacherID` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user',
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacherID`, `firstname`, `lastname`, `username`, `email`, `picture`, `role`, `password`) VALUES
(12, 'Daudi', 'MORICE', 'deogratius', 'deogratiusshayo99@gmail.com', 'images (2).png', 'admin', '$2y$10$5h11cU.HNj043PGo/yah6etgZJo3NnrFQCqrNNPE/OpwdOZ4A7lC2'),
(16, 'NKATA', 'AMAN', 'nkata', 'nkata@gmail.com', 'images (2).png', 'user', '$2y$10$vvZzk6oWDkS084YUGL.LNOMzVEnVjeLTNw/YweRFfJk/klh412AdG'),
(17, 'MANYAHII', 'M', 'manyahi', 'manyahi@gmail.com', 'download (1).png', 'user', '$2y$10$p2YeWglWDC.NwWCWgfzMOuSpnA1WPCQItXvBbVyI2GiLkYIDWSvh2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance1`
--
ALTER TABLE `attendance1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_studentID` (`studentID`),
  ADD KEY `fk_subject_id` (`subject_id`),
  ADD KEY `fk_teacherID` (`teacherID`);

--
-- Indexes for table `attendance2`
--
ALTER TABLE `attendance2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID2` (`studentID`),
  ADD KEY `FK_SubjectID2` (`subject_id`),
  ADD KEY `FK_TeacherID2` (`teacherID`);

--
-- Indexes for table `attendance3`
--
ALTER TABLE `attendance3`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID3` (`studentID`),
  ADD KEY `FK_SubjectID3` (`subject_id`),
  ADD KEY `FK_TeacherID3` (`teacherID`);

--
-- Indexes for table `attendance4`
--
ALTER TABLE `attendance4`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID4` (`studentID`),
  ADD KEY `FK_SubjectID4` (`subject_id`),
  ADD KEY `FK_TeacherID4` (`teacherID`);

--
-- Indexes for table `attendance5`
--
ALTER TABLE `attendance5`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID5` (`studentID`),
  ADD KEY `FK_SubjectID5` (`subject_id`),
  ADD KEY `FK_TeacherID5` (`teacherID`);

--
-- Indexes for table `attendance6`
--
ALTER TABLE `attendance6`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID6` (`studentID`),
  ADD KEY `FK_SubjectID6` (`subject_id`),
  ADD KEY `FK_TeacherID6` (`teacherID`);

--
-- Indexes for table `attendance7`
--
ALTER TABLE `attendance7`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_StudentID7` (`studentID`),
  ADD KEY `FK_SubjectID7` (`subject_id`),
  ADD KEY `FK_TeacherID7` (`teacherID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eventID`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`resultID`),
  ADD KEY `result` (`studentID`);

--
-- Indexes for table `std1_results`
--
ALTER TABLE `std1_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_student_id` (`studentID`);

--
-- Indexes for table `std2_results`
--
ALTER TABLE `std2_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_student` (`studentID`);

--
-- Indexes for table `std3_results`
--
ALTER TABLE `std3_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_studentS` (`studentID`);

--
-- Indexes for table `std4_results`
--
ALTER TABLE `std4_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_result` (`studentID`);

--
-- Indexes for table `std5_results`
--
ALTER TABLE `std5_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_students_id` (`studentID`);

--
-- Indexes for table `std6_results`
--
ALTER TABLE `std6_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_student6_id` (`studentID`);

--
-- Indexes for table `std7_results`
--
ALTER TABLE `std7_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fk_student7_id` (`studentID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `subjects_ibfk_1` (`teacherID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacherID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance1`
--
ALTER TABLE `attendance1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `attendance2`
--
ALTER TABLE `attendance2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance3`
--
ALTER TABLE `attendance3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance4`
--
ALTER TABLE `attendance4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance5`
--
ALTER TABLE `attendance5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attendance6`
--
ALTER TABLE `attendance6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance7`
--
ALTER TABLE `attendance7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `eventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `resultID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `std1_results`
--
ALTER TABLE `std1_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `std2_results`
--
ALTER TABLE `std2_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `std3_results`
--
ALTER TABLE `std3_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std4_results`
--
ALTER TABLE `std4_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std5_results`
--
ALTER TABLE `std5_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std6_results`
--
ALTER TABLE `std6_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std7_results`
--
ALTER TABLE `std7_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `studentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacherID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance1`
--
ALTER TABLE `attendance1`
  ADD CONSTRAINT `fk_studentID` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teacherID` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance2`
--
ALTER TABLE `attendance2`
  ADD CONSTRAINT `FK_StudentID2` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID2` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance3`
--
ALTER TABLE `attendance3`
  ADD CONSTRAINT `FK_StudentID3` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID3` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance4`
--
ALTER TABLE `attendance4`
  ADD CONSTRAINT `FK_StudentID4` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID4` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID4` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance5`
--
ALTER TABLE `attendance5`
  ADD CONSTRAINT `FK_StudentID5` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID5` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID5` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance6`
--
ALTER TABLE `attendance6`
  ADD CONSTRAINT `FK_StudentID6` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID6` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID6` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance7`
--
ALTER TABLE `attendance7`
  ADD CONSTRAINT `FK_StudentID7` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_SubjectID7` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_TeacherID7` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `results`
--
ALTER TABLE `results`
  ADD CONSTRAINT `result` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `std1_results`
--
ALTER TABLE `std1_results`
  ADD CONSTRAINT `fk_student_id` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE;

--
-- Constraints for table `std2_results`
--
ALTER TABLE `std2_results`
  ADD CONSTRAINT `fk_student` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `std3_results`
--
ALTER TABLE `std3_results`
  ADD CONSTRAINT `fk_studentS` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `std4_results`
--
ALTER TABLE `std4_results`
  ADD CONSTRAINT `fk_result` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `std5_results`
--
ALTER TABLE `std5_results`
  ADD CONSTRAINT `fk_students_id` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `std6_results`
--
ALTER TABLE `std6_results`
  ADD CONSTRAINT `fk_student6_id` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `std7_results`
--
ALTER TABLE `std7_results`
  ADD CONSTRAINT `fk_student7_id` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`teacherID`) REFERENCES `teachers` (`teacherID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
