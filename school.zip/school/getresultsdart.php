<?php

include 'database.php';

// Receive username and password from Flutter
$username = $_POST['username'];
$password = $_POST['password'];

// Query the database to verify username and password
$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    // User found, fetch user details
    $row = $result->fetch_assoc();
    $response['success'] = true;
    $response['message'] = 'Login successful';
    $response['studentID'] = $row['studentID'];
    $response['studentClass'] = $row['studentClass'];
    $response['firstname'] = $row['firstname'];
    $response['middlename'] = $row['middlename'];
    $response['lastname'] = $row['lastname'];
    $response['picture'] = $row['picture'];
} else {
    // User not found or invalid credentials
    $response['success'] = false;
    $response['message'] = 'Invalid username or password';
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
