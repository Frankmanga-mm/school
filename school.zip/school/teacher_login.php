<?php
session_start();
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement to fetch user data by email
    $checkEmailSQL = "SELECT * FROM teachers WHERE email = '$email'";

    // Execute the SQL statement
    $result = $conn->query($checkEmailSQL);

    // Check if the email exists
    if ($result->num_rows > 0) {
        // Fetch the user data
        $row = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $row['password'])) {
            $_SESSION['Email'] = $row['email'];
            $_SESSION['Username'] = $row['username'];
            $_SESSION['Profile'] = $row['picture'];
            $_SESSION['teacherID'] = $row['teacherID'];
            // Check the role
            if ($row['role'] == 'admin') {
                // Redirect to admin dashboard
                header("Location: Admin_dashboard.php");
                exit();
            } else {
                // Redirect to user dashboard
                header("Location: dashboard.php");
                exit();
            }
        } else {
            // Password is incorrect
            $error = "Incorrect password.";
        }
    } else {
        // Email does not exist
        $error = "Email not found.";
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Login</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Include Font Awesome -->
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
  }
  
  .container {
    max-width: 500px;
    margin: 50px auto;
    background-color: #ffffff; /* Changed background color for the form */
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    border: 1px solid #ccc; /* Added border around the form */
  }
  
  .header-container {
    background-color: grey; /* Background color for the header container */
    border-radius: 10px 10px 0 0; /* Rounded corners for the top */
    padding: 20px;
    margin-bottom: 20px;
  }
  
  h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #ffffff; /* Changed text color for the heading */
  }
  
  .form-group {
    margin-bottom: 20px;
    position: relative;
  }
  
  input[type="email"],
  input[type="password"] {
    width: calc(100% - 40px); /* Adjusted width to accommodate icon */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #f5f5f5; /* Added background color for input fields */
    padding-left: 35px; /* Added space for the icon */
  }

  input[type="email"]::placeholder,
  input[type="password"]::placeholder {
    color: #999999; /* Changed placeholder color */
  }

  .fa {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: 10px;
    color: black; /* Changed icon color to black */
    font-size: 18px; /* Increased icon size */
  }
  
  input[type="submit"] {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #007bff;
    color: #ffffff; /* Changed text color */
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  input[type="submit"]:hover {
    background-color: #0056b3;
  }

  .error-message {
    color: red;
    font-size: 14px;
  }
</style>
</head>
<body>

<div class="container">
  <div class="header-container">
    <h2>Teacher Login</h2>
  </div>
  
  <form action="teacher_login.php" method="POST">
    <div class="form-group">
      <i class="fa fa-envelope"></i>
      <input type="email" id="email" name="email" placeholder="    Email" required> <!-- Added spaces before Email -->
    </div>
    <div class="form-group">
      <i class="fa fa-lock"></i>
      <input type="password" id="password" name="password" placeholder="    Password" required> <!-- Added spaces before Password -->
    </div>
    <div class="form-group">
      <input type="submit" value="Login" name="login">
    </div>
    <div class="form-group">
      <span class="error-message"><?php echo isset($error) ? $error : ''; ?></span>
    </div>
  </form>
</div>

</body>
</html>
