<?php

include 'session.php';
include 'database.php';

// Initialize variables
$show_form = false;
$access_granted = false;
$attendance_records = [];

// Check if the "Add marks" button is clicked
if (isset($_POST['add_marks'])) {
    // Show the form to choose class and subject
    $show_form = true;
}

// Retrieve the email of the logged-in teacher from the session
$teacher_email = $_SESSION['Email'];
$teacherID = $_SESSION['teacherID'];

// Fetch classes and subjects data from the database for the logged-in teacher
$sql_classes = "SELECT DISTINCT class FROM subjects WHERE teacherID = ?";
$stmt_classes = $conn->prepare($sql_classes);
$stmt_classes->bind_param("s", $teacherID);
$stmt_classes->execute();
$result_classes = $stmt_classes->get_result();
$classes = [];
while ($row = $result_classes->fetch_assoc()) {
    $classes[] = $row['class'];
}
$stmt_classes->close();

$sql_subjects = "SELECT DISTINCT subject_name FROM subjects WHERE teacherID = ?";
$stmt_subjects = $conn->prepare($sql_subjects);
$stmt_subjects->bind_param("s", $teacherID);
$stmt_subjects->execute();
$result_subjects = $stmt_subjects->get_result();
$subjects = [];
while ($row = $result_subjects->fetch_assoc()) {
    $subjects[] = $row['subject_name'];
}
$stmt_subjects->close();

// Check if the form to choose class and subject is submitted
if (isset($_POST['choose_class_subject'])) {
    // Retrieve the selected class and subject
    $selected_class = $_POST['class'];
    $selected_subject = $_POST['subject'];

    // Query to check if the teacher has access to the selected subject of the selected class
    $sql_access_check = "SELECT * FROM subjects WHERE teacherID = ? AND class = ? AND subject_name = ?";
    $stmt_access_check = $conn->prepare($sql_access_check);
    $stmt_access_check->bind_param("sss", $teacherID, $selected_class, $selected_subject);
    $stmt_access_check->execute();
    $result_access_check = $stmt_access_check->get_result();

    if ($result_access_check->num_rows > 0) {
        // The teacher has access to the selected subject of the selected class
        $access_granted = true;

        // Get the appropriate table name based on the selected class
        $attendance_table_name = 'attendance' . $selected_class;

        // Query to fetch the attendance records from the specific class table
        $sql_attendance = "SELECT students.firstname, students.middlename, students.lastname, subjects.subject_name, $attendance_table_name.attendance_status, $attendance_table_name.uploaded_date FROM $attendance_table_name INNER JOIN students ON $attendance_table_name.studentID = students.studentID INNER JOIN subjects ON $attendance_table_name.subject_id = subjects.subject_id WHERE subjects.class = ? AND subjects.subject_name = ?";
        $stmt_attendance = $conn->prepare($sql_attendance);
        $stmt_attendance->bind_param("ss", $selected_class, $selected_subject);
        $stmt_attendance->execute();
        $result_attendance = $stmt_attendance->get_result();

        // Fetch attendance records into an array
        while ($row = $result_attendance->fetch_assoc()) {
            $attendance_records[] = $row;
        }
        $stmt_attendance->close();
    } else {
        // The teacher doesn't have access to the selected subject of the selected class
        $access_granted = false;
    }
}

// Search functionality
if (isset($_POST['search'])) {
    // Retrieve the search query
    $search_query = $_POST['search_query'];
    
    // Filter the attendance records based on the search query
    $filtered_records = [];
    foreach ($attendance_records as $record) {
        // Check for presence status
        if (stripos($search_query, 'present') !== false && stripos($record['attendance_status'], 'present') !== false) {
            $filtered_records[] = $record;
        }
        // Check for specific date
        else if (stripos($record['uploaded_date'], $search_query) !== false) {
            $filtered_records[] = $record;
        }
        // Check for names
        else if (stripos($record['firstname'], $search_query) !== false ||
                 stripos($record['middlename'], $search_query) !== false ||
                 stripos($record['lastname'], $search_query) !== false) {
            $filtered_records[] = $record;
        }
    }
    // Update attendance records with filtered records
    $attendance_records = $filtered_records;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attendance</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        /* Form Container Styles */
        .form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
        }
        .form-container h2 {
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 20px;
        }
        .form-container form {
            text-align: center;
        }
        .form-container label {
            display: block;
            margin-bottom: 10px;
        }
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-container button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-container button:hover {
            background-color: #45a049;
        }

        /* Attendance Container Styles */
        .attendance-container {
            margin: 20px auto;
            overflow-x: auto;
        }
        .attendance-container table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        .attendance-container th,
        .attendance-container td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .attendance-container th {
            background-color: #f2f2f2;
        }

        /* Search Container Styles */
        .search-container {
            margin-top: 20px;
            text-align: center;
        }
        .search-container input[type=text] {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .search-container button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .search-container button:hover {
            background-color: #45a049;
        }

        /* Responsive Styles */
        @media only screen and (max-width: 600px) {
            .form-container,
            .attendance-container {
                max-width: 90%;
                margin: 20px auto;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Panel Make Student Attendance</h2>

    <form action="" method="POST">
        <button type="submit" name="add_marks">View Students</button>
    </form>

    <?php
    if ($show_form) {
        ?>
        <form action="" method="POST">
            <div>
                <label for="class">Select Class:</label>
                <select id="class" name="class" required>
                    <option value="" disabled selected>Select Class</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class; ?>"><?php echo $class; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="subject">Select Subject:</label>
                <select id="subject" name="subject" required>
                    <option value="" disabled selected>Select Subject</option>
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo $subject; ?>"><?php echo $subject; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <button type="submit" name="choose_class_subject">Submit</button>
            </div>
        </form>
        <?php
    }

    if ($access_granted === false && isset($_POST['choose_class_subject'])) {
        echo "<p>You don't have access to that subject of that class.</p>";
    } else if ($access_granted === true && empty($attendance_records)) {
        echo "<p>No attendance records uploaded yet for the selected class and subject.</p>";
    }
    ?>
</div>


<?php
if (!empty($attendance_records)) {
    ?>
    <div class="attendance-container">
        <h3>Attendance Records</h3>

 

        <table>
            <thead>
            <tr>
                <th>Student Name</th>
                <th>Subject</th>
                <th>Attendance Status</th>
                <th>Attendance Date</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($attendance_records as $record): ?>
                <tr>
                    <td><?php echo $record['firstname'] . ' ' . $record['middlename'] . ' ' . $record['lastname']; ?></td>
                    <td><?php echo $record['subject_name']; ?></td>
                    <td><?php echo $record['attendance_status']; ?></td>
                    <td><?php echo $record['uploaded_date']; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php } ?>

</body>
</html>


