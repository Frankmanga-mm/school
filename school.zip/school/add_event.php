<?php
// Include the database connection file
include 'session.php';
include 'database.php';

// Check if the form is submitted
if(isset($_POST['submit'])) {
    // Retrieve form data
    $title = $_POST['title'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    // Insert the event into the database
    $insert_event_query = "INSERT INTO events (title, date, time, location, description) VALUES ('$title', '$date', '$time', '$location', '$description')";
    if ($conn->query($insert_event_query) === TRUE) {
        // Redirect to a success page or display a success message
        header("refresh:2; url=view_event.php");
        exit();
    } else {
        // Handle errors if any
        echo "Error: " . $insert_event_query . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1900px;
            margin: 20px auto;
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            position: relative;
        }

        h2::after {
            content: "";
            display: block;
            width: 40%;
            height: 5px;
            border: 1px solid #33652f;
            border-radius : 10px;
            background-color: #33652f;
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .back-to-dashboard {
    background-color: #4CAF50;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin: 10px 0; /* Adjust margin */
    display: block;
    text-decoration: none;
    width: 150px;
}

        .back-to-dashboard:hover {
            background-color: #45a049;
        }

        form {
            margin-top: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <a href="Admin_dashboard.php" class="back-to-dashboard">Back to Dashboard</a>
    <div class="container">
        <h2>Add and Post Upcoming Event/Events</h2>
        <form action="add_event.php" method="post">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
            
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>
            
            <label for="time">Time:</label>
            <input type="time" id="time" name="time" required>
            
            <label for="location">Location:</label>
            <input type="text" id="location" name="location">
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4"></textarea>
            
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</body>
</html>

